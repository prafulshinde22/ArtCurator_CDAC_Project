export class Image {
    image:any;
    Image(){}
}
