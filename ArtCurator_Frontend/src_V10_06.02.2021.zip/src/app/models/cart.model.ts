export class Cart {
    id: number=0;
    amount:number=0;
    art_name:string="";
    artist_name:string="";
    image:any;
    user_id:number=0;
    product_id: number=0;  
}