import { ProductDto } from './product-dto.model';

describe('ProductDto', () => {
  it('should create an instance', () => {
    expect(new ProductDto()).toBeTruthy();
  });
});
