import { Image } from './image.model';

describe('Image', () => {
  it('should create an instance', () => {
    expect(new Image()).toBeTruthy();
  });
});
