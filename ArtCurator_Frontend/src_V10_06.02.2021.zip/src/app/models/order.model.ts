export class Order { 
    order_id:number=0;
    product_id:number=0;
    amount:number=0;
    order_time:string="";
	Order(){}
}