export class Address {
    id:number=0;    
    apartment:string="";
    city:string="";
    country:string="";
    pin:number=0;
    state:string="";
	street:string="";
    user_id:number=0;
	Address(){}
}
