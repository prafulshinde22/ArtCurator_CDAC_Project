import { AddProduct } from './add-product.model';

describe('AddProduct', () => {
  it('should create an instance', () => {
    expect(new AddProduct()).toBeTruthy();
  });
});
