import { UserRegistration } from './user-registration.model';

describe('UserRegistration', () => {
  it('should create an instance', () => {
    expect(new UserRegistration()).toBeTruthy();
  });
});
