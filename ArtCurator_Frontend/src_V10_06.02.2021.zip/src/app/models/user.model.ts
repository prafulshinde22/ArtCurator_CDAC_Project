export class User {
    id:Number=0;
    name:string='';
	email:string='';
	password:string='';  
	phone:number=0;
	dob:Date=new Date;
	role:string='';
	User(){}
}
