//import { Cart } from './cart';
import { CartItem } from './cart-item';

describe('Cart', () => {
  it('should create an instance', () => {
   // expect(new CartIte()).toBeTruthy();
  });
});
