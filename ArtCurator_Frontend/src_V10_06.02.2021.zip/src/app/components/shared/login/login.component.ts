import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { Login } from '../../../models/login.model';
import { Router } from '@angular/router';
import { UserService } from '../../../services/user.service';

export var isSeller: boolean = false;
export var isBuyer: boolean = false;

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loginSuccess: boolean = null;
  constructor(private router: Router, private builder: FormBuilder, private userService: UserService) { }

  ngOnInit() {
    this.buildForm();
  }

  buildForm() {
    this.loginForm = this.builder.group({
      name: ['', Validators.required],
      password: ['', Validators.required]
    })
  }

  login() {
    this.userService.authenticate
      (new Login(this.loginForm.get('name').value, this.loginForm.get('password').value)).subscribe(
        response => {
          console.log(response.length);
          this.loginSuccess = true;
          this.userService.getUser();
        },
        error => {
          alert("invalid login....");
          this.loginSuccess = false;
        },
        () => {
          setTimeout(() => {
            console.log("In loginnnn.");
            console.log(localStorage.getItem('user_role'));
            console.log(window.localStorage.user_role);

            if (window.localStorage.getItem('user_role') === "SELLER") {
              isSeller = true;
              console.log("Set isSeller.");
            }
            if (window.localStorage.getItem('user_role') === "BUYER") {
              isBuyer = true;
              console.log("Set isBuyer.");
            }
          }, 1000);
        }
      );
  }
}