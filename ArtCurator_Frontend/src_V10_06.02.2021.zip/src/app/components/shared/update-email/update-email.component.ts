import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { Router } from '@angular/router';
import { UserService } from '../../../services/user.service'
import { isBuyer, isSeller } from '../login/login.component';

@Component({
  selector: 'app-update-email',
  templateUrl: './update-email.component.html',
  styleUrls: ['./update-email.component.css']
})
export class UpdateEmailComponent implements OnInit {

  updateEmailForm: FormGroup;
  isSeller: boolean = isSeller;
  isBuyer: boolean = isBuyer;
  isUpdated: boolean = false;

  constructor(private builder: FormBuilder,
    private userService: UserService,
    private router: Router) { }

  ngOnInit() {
    this.buildForm()
  }

  buildForm() {
    this.updateEmailForm = this.builder.group({
      newEmail: ['', [Validators.required, Validators.email]]
    })
  }

  updateEmail() {
    this.userService.changeEmail(this.updateEmailForm.get('newEmail').value).subscribe(
      response => {
        console.log("Email updated.");
        this.isUpdated = true;
        // window.alert("Logging you out. Please login again with new email ID.");
        this.userService.logout();
        setTimeout(() => {
          this.router.navigateByUrl('/login');
        }, 5000);
      },
      error => {
        console.log("Email updation unsuccessful.");
      },
      () => {
        if (isSeller) {
          setTimeout(function () {
            this.router.navigateByUrl('app-nav-seller');
          }, 5000);
        }

        if (isBuyer) {
          setTimeout(function () {
            this.router.navigateByUrl('app-nav-user');
          }, 5000);
        }
      }
    );
  }

}
