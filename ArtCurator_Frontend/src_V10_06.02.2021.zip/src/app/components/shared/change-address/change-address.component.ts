import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../../../services/user.service';
import { isBuyer, isSeller } from '../login/login.component';
import { Address }  from '../../../models/address.model';
import { AddressService } from 'src/app/services/address.service';

@Component({
  selector: 'app-change-address',
  templateUrl: './change-address.component.html',
  styleUrls: ['./change-address.component.css']
})

export class ChangeAddressComponent implements OnInit {
  changeAddressForm: FormGroup;
  isSeller: boolean = isSeller;
  isBuyer: boolean = isBuyer;
  isUpdated: boolean = false;

  constructor(private builder: FormBuilder,
    private addressService: AddressService,
    private router: Router) { }

  ngOnInit() {
    this.buildForm();
  }

  buildForm() {
    this.changeAddressForm = this.builder.group({
      apartment: ['', Validators.required],
      street: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      country: ['', Validators.required],
      pin: ['', Validators.required]
    })
  }

  changeAddress() {
    console.log(this.changeAddressForm.value);
    this.addressService.changeAddress(this.changeAddressForm.value).subscribe(
      response => {
        console.log("Address updated.");
        this.isUpdated = true;
      },
      error => {
        console.log("Address updation unsuccessful.");
      },
      () => {
        if(isSeller) {
          setTimeout(function() {
            this.router.navigateByUrl('app-nav-seller');
          }, 5000);
        }

        if(isBuyer) {
          setTimeout(function() {
            this.router.navigateByUrl('app-nav-user');
          }, 5000);
        }
      }
    );
  }
}