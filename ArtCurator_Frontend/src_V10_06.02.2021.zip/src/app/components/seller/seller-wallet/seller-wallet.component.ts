import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-seller-wallet',
  templateUrl: './seller-wallet.component.html',
  styleUrls: ['./seller-wallet.component.css']
})
export class SellerWalletComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
