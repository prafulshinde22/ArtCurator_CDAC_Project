import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.model';
@Component({
  selector: 'app-nav-user',
  templateUrl: './nav-user.component.html',
  styleUrls: ['./nav-user.component.css']
})
export class NavUserComponent implements OnInit {
  user:User=new User();
  constructor(private userService:UserService,private router:Router) { }

  ngOnInit(): void {
    this.userService.getUserById().subscribe(response=>{
      console.log("User :"+response.name);
      this.user=response;
    });
  }

  logout(){
    this.userService.logout();
    setTimeout(()=>{
      this.router.navigateByUrl('/login');
    },3000);
  }

}
