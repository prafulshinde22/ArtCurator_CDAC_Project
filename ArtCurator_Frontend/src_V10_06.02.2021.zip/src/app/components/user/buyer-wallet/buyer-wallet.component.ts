import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buyer-wallet',
  templateUrl: './buyer-wallet.component.html',
  styleUrls: ['./buyer-wallet.component.css']
})
export class BuyerWalletComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
